"""Azure Provisioning Device Models

This package provides object models for use within the Azure Provisioning Device SDK.
"""

from .registration_result import RegistrationResult  # noqa: F401
